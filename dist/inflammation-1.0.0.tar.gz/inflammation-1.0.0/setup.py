# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['inflammation']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.6.2,<4.0.0', 'numpy>=1.23.5,<2.0.0']

setup_kwargs = {
    'name': 'inflammation',
    'version': '1.0.0',
    'description': 'Analyse patient inflammation data',
    'long_description': '# Inflam\n\nInflam is a data management system written in python that manages trial data used in clinical inflammation studies.\n\n## Main features\nHere are some key features of Inflam:\n\n- provide basic statistical analysis over clinical trial data\n- Ability to work on trail data in CSV format\n- Generate plots of trail data\n- Analytical functions and views can be easily extended based on its Model-view-Controller architecture\n\n## Prequisites\n\n\n\n###',
    'author': 'Tam Sabapathy',
    'author_email': 'tamilarasan.sabapathy@stfc.ac.uk',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
