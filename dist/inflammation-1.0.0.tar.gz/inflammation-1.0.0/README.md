# Inflam

Inflam is a data management system written in python that manages trial data used in clinical inflammation studies.

## Main features
Here are some key features of Inflam:

- provide basic statistical analysis over clinical trial data
- Ability to work on trail data in CSV format
- Generate plots of trail data
- Analytical functions and views can be easily extended based on its Model-view-Controller architecture

## Prequisites



###